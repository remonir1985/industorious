<?php
/*
Plugin Name:industorias Helper
Plugin URI:https://itmonir.com
description:This maps helper
Version:1.0.0
Author: Monir
Author URI:https://itmonir.com
License:GPL2




*/
require dirname(__FILE__).'/shortcode/kmap.php';
require dirname(__FILE__).'/shortcode/special.php';
require dirname(__FILE__).'/shortcode/contenta.php';
require dirname(__FILE__).'/shortcode/mybanner.php';
require dirname(__FILE__).'/shortcode/testimonial.php';




 ?>