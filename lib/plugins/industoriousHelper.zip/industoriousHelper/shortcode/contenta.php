<?php
add_action('init','Taiba_contenta_service');
if(!function_exists('Taiba_contenta_service')):

function Taiba_contenta_service(){
	if(function_exists('kc_add_map')):
	
	kc_add_map(array(
		
		'contenta'			=>	array(
			'name'	=>esc_html('contenta','taiba'),
			'icon'			=>'fa fa-map',
			'category'		=> 'Gmap',
			'params'		=> array(
			
				array(
				'name'	=>'title',
				'label'	=>esc_html('Title','taiba'),
				'type'	=>'text',
				'value'	=>'Main Title Here',
				
			),
			array(
				'name'	=>'desc',
				'label'	=>esc_html('Description','taiba'),
				'type'	=>'textarea',
				'value'	=>'Description heare',
			
			),
			array(
				'name'	=>'icon',
				'label'	=>esc_html('ICON','taiba'),
				'type'	=>'icon_picker',
				
			
			),
			

			


		)
	)));
endif;
		
}

endif;

function taiba_contenta_shortcode($atts,$content){
	ob_start();
	$contentas_att = shortcode_atts(array(
		'title'	=>'',
		'desc'=>'',
		'icon'=>''
		
	),$atts);
	extract($contentas_att);

	?>
			<section>
				<div class="content">
								<header>
									<a href="#" class="icon <?php echo esc_attr($icon); ?>"><span class="label">Icon</span></a>
									<h3><?php echo esc_html($title); ?></h3>
								</header>
								<p><?php echo esc_html($desc); ?></p>
							</div>
				</section>	
						
						



<?php
	return ob_get_clean();

}

add_shortcode( 'contenta', 'taiba_contenta_shortcode' );

 ?>