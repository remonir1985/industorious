<?php
add_action('init','Taiba_mybanner_service');
if(!function_exists('Taiba_mybanner_service')):

function Taiba_mybanner_service(){
	if(function_exists('kc_add_map')):
	
	kc_add_map(array(
		
		'mybanner'			=>	array(
			'name'			=>esc_html('mybanner','taiba'),
			'icon'			=>'fa fa-map',
			'category'		=> 'Gmap',
			'params'		=> array(
			
				array(
				'name'	=>'title',
				'label'	=>esc_html('Title','taiba'),
				'type'	=>'text',
				'value'	=>'Main Title Here',
				
			),
			array(
				'name'	=>'desc',
				'label'	=>esc_html('Description','taiba'),
				'type'	=>'textarea',
				'value'	=>'Description heare',
			
			),
			array(
				'name'	=>'link',
				'label'	=>esc_html('ICON','taiba'),
				'type'	=>'link',
				
			
			),
			

			


		)
	)));
endif;
		
}

endif;

function taiba_mybanner_shortcode($atts,$content){
	ob_start();
	$mybanners_att = shortcode_atts(array(
		'title'	=>'',
		'desc'=>'',
		'link'=>''
		
	),$atts);
	extract($mybanners_att);

	?>
		<section id="banner">
				<div class="inner">
					<h1><?php echo esc_html($title); ?></h1>
					<p><?php echo esc_html($desc); ?></p>
				</div>
				<video autoplay loop muted playsinline src="<?php echo esc_url($link); ?>"></video>
			</section>
						



<?php
	return ob_get_clean();

}

add_shortcode( 'mybanner', 'taiba_mybanner_shortcode' );

 ?>