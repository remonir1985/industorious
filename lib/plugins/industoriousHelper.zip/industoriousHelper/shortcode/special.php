<?php
add_action('init','Taiba_special_service');
if(!function_exists('Taiba_special_service')):

function Taiba_special_service(){
	if(function_exists('kc_add_map')):
	
	kc_add_map(array(
		
		'special1'			=>	array(
			'name'	=>esc_html('special','taiba'),
			'icon'			=>'fa fa-map',
			'category'		=> 'Gmap',
			'params'		=> array(
			
				array(
				'name'	=>'title',
				'label'	=>esc_html('Title','taiba'),
				'type'	=>'text',
				'value'	=>'Main Title Here',
				
			),
			array(
				'name'	=>'desc',
				'label'	=>esc_html('Description','taiba'),
				'type'	=>'textarea',
				'value'	=>'Description heare',
			
			)
			

			


		)
	)));
endif;
		
}

endif;

function taiba_special_shortcode($atts,$content){
	ob_start();
	$specials_att = shortcode_atts(array(
		'title'	=>'',
		'desc'=>'',
		
	),$atts);
	extract($specials_att);

	?>

			<div class="inner">
<header class="special">
						<h2><?php echo esc_html($title); ?></h2>
						<p><?php echo esc_html($desc); ?></p>
					</header>
				</div>
		



<?php
	return ob_get_clean();

}

add_shortcode( 'special1', 'taiba_special_shortcode' );

 ?>