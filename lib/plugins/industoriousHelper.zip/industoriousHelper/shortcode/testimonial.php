<?php
add_action('init','Taiba_testimonial_service');
if(!function_exists('Taiba_testimonial_service')):

function Taiba_testimonial_service(){
	if(function_exists('kc_add_map')):
	
	kc_add_map(array(
		
		'testimonial'			=>	array(
			'name'			=>esc_html('testimonial','taiba'),
			'icon'			=>'fa fa-map',
			'category'		=> 'Gmap',
			'params'		=> array(
			
				array(
				'name'	=>'name',
				'label'	=>esc_html('Name','taiba'),
				'type'	=>'text',
				'value'	=>'Main Title Here',
				
			),
			array(
				'name'	=>'desc',
				'label'	=>esc_html('Description','taiba'),
				'type'	=>'textarea',
				'value'	=>'Description heare',
			
			),
			array(
				'name'	=>'degination',
				'label'	=>esc_html('Degination','taiba'),
				'type'	=>'text',
				
			
			),
			array(
				'name'	=>'image',
				'label'	=>esc_html('image','taiba'),
				'type'	=>'attach_image',
				
			
			),
			

			


		)
	)));
endif;
		
}

endif;

function taiba_testimonial_shortcode($atts,$content){
	ob_start();
	$testimonials_att = shortcode_atts(array(
		'name'	=>'',
		'desc'=>'',
		'degination'=>'',
		'image'	=>''
		
	),$atts);
	extract($testimonials_att);

	?>
		<section>
							<div class="content">
								<blockquote>
									<p><?php echo esc_html($desc); ?></p>
								</blockquote>
								<div class="author">
									<div class="image">
										<?php $img_src = wp_get_attachment_image_src( $image, 'small' ); ?>
										<img src="<?php echo esc_url($img_src[0]); ?>" alt="">
									</div>
									<p class="credit">- <strong><?php echo esc_html($name); ?></strong> <span><?php echo esc_html($degination); ?></span></p>
								</div>
							</div>
						</section>
						



<?php
	return ob_get_clean();

}

add_shortcode( 'testimonial', 'taiba_testimonial_shortcode' );

 ?>