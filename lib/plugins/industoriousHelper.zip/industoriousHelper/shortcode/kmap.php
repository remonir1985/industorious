<?php
add_action('init','Taiba_map_service');
if(!function_exists('Taiba_map_service')):

function Taiba_map_service(){
	if(function_exists('kc_add_map')):
	
	kc_add_map(array(
		
		'map'			=>	array(
			'name'	=>esc_html('GMAP','taiba'),
			'icon'			=>'fa fa-map',
			'category'		=> 'google_map',
			'params'		=> array(
			
				array(
				'name'	=>'width',
				'label'	=>esc_html('Width','taiba'),
				'type'	=>'text',
				'value'	=>'300',
				'description'	=>' this google map width'
			),
			array(
				'name'	=>'height',
				'label'	=>esc_html('Height','taiba'),
				'type'	=>'text',
				'value'	=>'200',
				'description'	=>' this google map height'
			),
			array(
				'name'	=>'place',
				'label'	=>esc_html('Location name','taiba'),
				'type'	=>'text',
				'value'	=>'dhaka',
				'description'	=>' this Location name here'
			),
			array(
				'name'	=>'zoom',
				'label'	=>esc_html('ZOOM','taiba'),
				'type'	=>'text',
				'value'	=>'300',
				'description'	=>' this Zoom here'
			)

			


		)
	)));
endif;
		
}

endif;

function taiba_map_shortcode($atts,$content){
	ob_start();
	$maps_att = shortcode_atts(array(
		'width'	=>'',
		'height'=>'',
		'place'	=>'',
		'zoom'	=>''

	),$atts);
	extract($maps_att);

	?>
<div>
    <div>
        <iframe width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>"
                src="https://maps.google.com/maps?q=<?php echo esc_html($place); ?>&t=&z=<?php echo esc_html($zoom); ?>&ie=UTF8&iwloc=&output=embed"
                frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
        </iframe>
    </div>
</div>



<?php
	return ob_get_clean();

}

add_shortcode( 'map', 'taiba_map_shortcode' );

 ?>